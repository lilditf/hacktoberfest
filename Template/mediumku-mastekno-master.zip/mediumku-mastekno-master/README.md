<h1>Mediumku Wordpress Theme</h1>
<p>Template wordpress seo, responsive dan fast loading. Untuk dapat memakai template wordpress gratis mirip medium, banyak kelebihan jika menggunakan template wp ini.</p>
<img src="https://raw.githubusercontent.com/mastekno-com/mediumku-mastekno/master/screenshot.png" style="wdith:100%"/>
<h1><a href="https://github.com/mastekno-com/mediumku-mastekno/archive/master.zip">DOWNLOAD</a> - <a href="https://www.bropulsa.com/post/">DEMO</a></h1>
<p>Banyak di pakai oleh beberapa website ternama, template ini sangat cepat di akses dan memiliki berbagai kelebihan yang ada.</p>

<h2>Cara Instalasi</h2>
<ol>
  <li>Langkah pertama masuk ke wordpress kalian</li>
  <li>Masuk ke bagian Tampilan >> Tema >> Tambah Baru >> Unggah Tema</li>
  <li>Kemudian masukan file tema yang sudah di download</li>
</ol>

<br/>
<h2>WAJIB ADA</h2>
Pastikan Install Plugin Berikut: https://id.wordpress.org/plugins/auto-post-thumbnail/
</br>(Tidak Diperlukan, jika semua post memiliki gambar unggulan).

<br/>
<h3>Fitur Mediumku Wordpress</h3>
<table cellpadding="0" cellspacing="0" style="text-align: left;"><tbody>
<tr>             <th>Features</th>             <th>Availability</th>         </tr>
<tr>             <td>Responsive</td>             <td>True</td>         </tr>
<tr>             <td>Google Testing Tool Validator</td>             <td>True</td>         </tr>
<tr>             <td>Responsive</td>             <td>True</td>         </tr>
<tr>             <td>ADS Optimize</td>             <td>True </td>         </tr>
<tr>             <td>SEO Friendly</td>             <td>True</td>         </tr>
<tr>             <td>Dynamic Heading</td>             <td>True</td>         </tr>
<tr>             <td>Menu Navigation</td>             <td>True</td>         </tr>
<tr>             <td>High CTR</td>             <td>True</td>         </tr>
<tr>             <td>2 Column</td>             <td>True</td>         </tr>
<tr>             <td>Footer Menu</td>             <td>True</td>         </tr>
<tr>             <td>Related Posts</td>             <td>True</td>         </tr>
<tr>             <td>Search Box</td>             <td>True</td>         </tr>
<tr>             <td>Social Share Button</td>             <td>True</td>         </tr>
</tbody> </table>
<br/>
<h2>F.A.Q</h2>
<h3>Perbedaan</h2>
<p>Sumber Template HTML &amp; CSS di ambil dari Mediumish yang merupakan GPLV3 dan begitu juga template ini, segala sumber php sistem dan alur telah di modifikasi. Source code ini bersifat open source, bebas untuk dipakai dan digunakan (MASIH DALAM GPLV3).</p>

<h3>Perubahan</h3>
<ul>
  <li>Perubahan Basis Kode PHP (System Template)</li>
  <li>Penambahan Fitur Kontrol Posisi Iklan dalam admin panel</li>
  <li>Pembangunan Kode tanpa Kustomisasi dari Dashboard</li>
  <li>Penyesuaian Struktur Kode PHP, dalam semua file.</li>
</ul>

<br/>
<h2>Ketentuan</h2>
LICENSE GPLV3 Kesimpulan 
<p>1. Siapa saja dapat menyalin, memodifikasi, dan mendistribusikan perangkat lunak ini.</p>
<p>2. Anda harus memasukkan lisensi dan pemberitahuan hak cipta dengan masing-masing dan setiap distribusi.</p>
<p>3. Anda dapat menggunakan perangkat lunak ini secara pribadi.</p>
<p>4. Anda dapat menggunakan perangkat lunak ini untuk tujuan komersial.</p>
<p>5. Jika Anda berani membangun bisnis Anda hanya dari kode ini, Anda berisiko open-source seluruh basis kode.</p>
<p>6. Jika Anda memodifikasinya, Anda harus menunjukkan perubahan yang dilakukan pada kode.</p>
<p>7. Segala modifikasi dari basis kode ini HARUS didistribusikan dengan lisensi yang sama, GPLv3.</p>
<p>8. Perangkat lunak ini disediakan tanpa jaminan.</p>
<p>9. Pembuat perangkat lunak atau lisensi tidak dapat bertanggung jawab atas segala kerusakan yang ditimbulkan oleh perangkat lunak.</p>
<br/>
LICENSE GPLV3 Conclusion
<p>1. Anyone can copy, modify and distribute this software.</p>
<p>2. You have to include the license and copyright notice with each and every distribution.</p>
<p>3. You can use this software privately.</p>
<p>4. You can use this software for commercial purposes.</p>
<p>5. If you dare build your business solely from this code, you risk open-sourcing the whole code base.</p>
<p>6. If you modify it, you have to indicate changes made to the code.</p>
<p>7. Any modifications of this code base MUST be distributed with the same license, GPLv3.</p>
<p>8. This software is provided without warranty.</p>
<p>9. The software author or license can not be held liable for any damages inflicted by the software.</p>

<p>Jadi dilarang menghapus hak cipta pencipta dan kontributor, tapi boleh menambahkan. Serta wajib menyertakan license.</p>
