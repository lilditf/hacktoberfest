<?php get_header(); ?>
<div class="site-content">
	<div class="container">
		<section class="recent-posts">
	        <div class="section-title">
	        	<h2><span>
	        		404 NOT FOUND
	        	</span></h2>
	        </div>
			<div class="row masonrygrid listrecent">
				<p>You can back to home or open other page.</p>
				<p>:) Thankyou</p>
			</div>
		</section>
	</div>
</div>
<?php get_footer(); ?>